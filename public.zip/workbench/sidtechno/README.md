# Customlogin

![License](https://img.shields.io/badge/license-MIT-blue.svg) [![Latest Stable Version](https://img.shields.io/packagist/v/sidtechno/customlogin.svg)](https://packagist.org/packages/sidtechno/customlogin) [![Total Downloads](https://img.shields.io/packagist/dt/sidtechno/customlogin.svg)](https://packagist.org/packages/sidtechno/customlogin)

A [Flarum](http://flarum.org) extension. this is use for customlogin where user email valid or not 

## Installation

Install with composer:

```sh
composer require sidtechno/customlogin:"*"
```

## Updating

```sh
composer update sidtechno/customlogin:"*"
php flarum migrate
php flarum cache:clear
```

## Links

- [Packagist](https://packagist.org/packages/sidtechno/customlogin)
- [GitHub](https://github.com/sidtechno/customlogin)
- [Discuss](https://discuss.flarum.org/d/PUT_DISCUSS_SLUG_HERE)
