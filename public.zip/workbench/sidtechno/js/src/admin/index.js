import app from 'flarum/admin/app';
import CustomAdminPage from './components/CustomAdminPage';

app.initializers.add('sidtechno/customlogin', () => {
  app.extensionData
    .for('sidtechno/customlogin') // Changed to match your extension id
    .registerPage({
      component: CustomAdminPage,
      icon: 'fas fa-chart-bar', // Choose an appropriate FontAwesome icon
      label: 'Custom Data',
      path: '/custom-data',
    });
  console.log('[sidtechno/customlogin] Hello, admin!');
});
