import app from 'flarum/common/app';

app.initializers.add('sidtechno/customlogin', () => {
  console.log('[sidtechno/customlogin] Hello, forum and admin!');
});
