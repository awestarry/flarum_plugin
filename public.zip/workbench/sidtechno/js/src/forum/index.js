import app from 'flarum/forum/app';
import SessionDropdown from 'flarum/components/SessionDropdown';
import CustomSignupModal from './components/CustomSignupModal';

app.initializers.add('sidtechno/customlogin', () => {

  console.log(app);

  app.modalManager.replace('signup', CustomSignupModal);
  extend(SessionDropdown.prototype, 'items', function (items) {
    items.add('sign-up',
        <button onclick={() => app.modal.show(CustomSignupModal)}>
            {app.translator.trans('your-extension.forum.sign_up_button')}
        </button>
    );
});
  console.log('[sidtechno/customlogin] Hello, forum!');
});
