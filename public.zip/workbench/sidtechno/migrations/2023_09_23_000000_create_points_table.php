<?php

use Illuminate\Database\Schema\Builder;
use Illuminate\Database\Schema\Blueprint;

return [
    'up' => function (Builder $schema) {
        // Define the changes to the database structure here.
        if (!$schema->hasTable('points')) {
            $schema->create('points', function ($table) {
                $table->increments('id');
                $table->integer('post_id')->index();
                $table->text('point_reason');
                $table->integer('points');
                $table->timestamps();
            });
        }
    },

    'down' => function (Builder $schema) {
        // Reverse the changes to the database structure here.
        if ($schema->hasTable('points')) {
            $schema->drop('points');
        }
    },
];
