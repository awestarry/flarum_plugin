<?php

namespace Sidtechno\Customlogin\Model;

use Flarum\Database\AbstractModel;

class Points extends AbstractModel
{
    protected $table = 'points';
}
