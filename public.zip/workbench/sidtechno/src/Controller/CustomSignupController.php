<?php

namespace Sidtechno\Customlogin\Controller;

use Flarum\Api\Controller\AbstractCreateController;
use Flarum\Settings\SettingsRepositoryInterface;
use Illuminate\Support\Arr;
use Psr\Http\Message\ServerRequestInterface;
use Tobscure\JsonApi\Document;
use Flarum\User\Command\RegisterUser;
use Illuminate\Contracts\Bus\Dispatcher;
use Flarum\User\UserValidator;
use Flarum\Http\RequestUtil;
use Flarum\User\User;
use Sidtechno\Customlogin\Serializer\UserSerializer;
use Laminas\Diactoros\Response\JsonResponse;
use Psr\Http\Message\ServerRequestInterface as Request;
use Flarum\User\RegistrationToken;
use Flarum\Foundation\ErrorHandling\HandledError;
use Flarum\User\Exception\PermissionDeniedException;

class CustomSignupController extends AbstractCreateController
{
    protected $bus;
    protected $settings;
    protected $validator;
    public $serializer = UserSerializer::class;
    public function __construct(Dispatcher $bus, SettingsRepositoryInterface $settings, UserValidator $validator)
    {
        $this->bus = $bus;
        $this->settings = $settings;
        $this->validator = $validator;
    }

    protected function data(ServerRequestInterface $request, Document $document)
    {
        $attributes = Arr::get($request->getParsedBody(), 'data.attributes', []);

        $username = Arr::get($attributes, 'username');
        $email = Arr::get($attributes, 'email');
        $password = Arr::get($attributes, 'password');
        // $username = 'razak_bhuto';
        // $email ='razak.bhutto1110@gmail.com';
        // $password = 12345678;

        if (!$this->settings->get('allow_sign_up')) {
            throw new \Exception('Sign up is not allowed on this forum.');
        }
        $isEmailConfirmed = true;
        $user = User::register($username, $email, $password);
        $user->activate();
        $user->save();

        return $user;
    }
}
