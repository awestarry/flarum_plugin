<?php
namespace Sidtechno\Customlogin\Controller;

use Sidtechno\Customlogin\Serializer\PointsSerializer;
use Psr\Http\Message\ServerRequestInterface;
use Tobscure\JsonApi\Document;
use Tobscure\JsonApi\Collection;
use Sidtechno\Customlogin\Model\Points;
use Flarum\Api\Controller\AbstractListController;


class PointController extends AbstractListController
{
    public $serializer = PointsSerializer::class;
    public $sortFields = [];

    /**
     * {@inheritdoc}
     */
    protected function data(ServerRequestInterface $request, Document $document)
    {
        return Points::all();

    }
}
