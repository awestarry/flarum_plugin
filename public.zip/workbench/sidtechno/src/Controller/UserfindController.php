<?php

namespace Sidtechno\Customlogin\Controller;

use Flarum\Api\Controller\AbstractCreateController;
use Psr\Http\Message\ServerRequestInterface;
use Tobscure\JsonApi\Document;
use Flarum\User\User;
use Sidtechno\Customlogin\Model\SecurityQuestion;
use Illuminate\Support\Arr;
use Sidtechno\Customlogin\Serializer\SecuritySerializer;
use Tobscure\JsonApi\Collection;
use Flarum\Api\Controller\AbstractListController;


class UserfindController extends AbstractCreateController
{
    public  $serializer = SecuritySerializer::class;

    protected function data(ServerRequestInterface $request, Document $document)
    {
        $actor = $request->getAttribute('actor');
        $attributes = Arr::get($request->getParsedBody(), 'data.attributes', []);
        $username = Arr::get($attributes, 'username');
         $username = 'razak_bhuto';
        $user = User::where('username', $username)
            ->orWhere('email', $username)->first();
        if (!$user) {
            return 'User Not found';
        }
       $question = SecurityQuestion::where('user_id', $user->id)->first();
       return $question;
     }

}
