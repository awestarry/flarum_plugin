<?php

namespace Sidtechno\Customlogin\Controller;

use Flarum\Api\Controller\AbstractCreateController;
use Sidtechno\Customlogin\Serializer\PointsSerializer;
use Illuminate\Contracts\Bus\Dispatcher;
use Psr\Http\Message\ServerRequestInterface;
use Sidtechno\Customlogin\Serializer\UserCusSerializer;
use Tobscure\JsonApi\Document;
use Flarum\User\User;
use Flarum\Api\Controller\AbstractListController;
use Zend\Diactoros\Response\JsonResponse;

class UserController extends AbstractCreateController
{
    public $serializer = UserCusSerializer::class;
    public $sort = null;

    /**
     * {@inheritdoc}
     */
    public $sortFields = [];
    protected $bus;

    protected function data(ServerRequestInterface $request, Document $document)
    {
        $actor = $request->getAttribute('actor');
        $id = $request->getAttribute('routeParameters')['id'];
        return User::find($id);

    }
}
