<?php

namespace Sidtechno\Customlogin\Controller;

use Flarum\Api\Controller\AbstractCreateController;
use Sidtechno\Customlogin\Serializer\PointsSerializer;
use Illuminate\Contracts\Bus\Dispatcher;
use Psr\Http\Message\ServerRequestInterface;
use Tobscure\JsonApi\Document;
use Sidtechno\Customlogin\Model\Points;
use Flarum\Api\Controller\AbstractListController;
use Zend\Diactoros\Response\JsonResponse;

class PointsController extends AbstractCreateController
{
    public $serializer = PointsSerializer::class;
    public $sort = null;

    /**
     * {@inheritdoc}
     */
    public $sortFields = [];
    protected $bus;

    protected function data(ServerRequestInterface $request, Document $document)
    {
        $id = $request->getAttribute('routeParameters')['id'];
        return Points::find($id);

    }
}
