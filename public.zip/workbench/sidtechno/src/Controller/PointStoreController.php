<?php

namespace Sidtechno\Customlogin\Controller;

use Flarum\Api\Controller\AbstractCreateController;
use Psr\Http\Message\ServerRequestInterface;
use Tobscure\JsonApi\Document;
use Illuminate\Support\Arr;
use Sidtechno\Customlogin\Serializer\PointsSerializer;
use Sidtechno\Customlogin\Model\Points; // Import the Point model

class PointStoreController extends AbstractCreateController
{
    /**
     * {@inheritdoc}
     */
    public $serializer = PointsSerializer::class;

    /**
     * {@inheritdoc}
     */
    public $include = [];

    /**
     * {@inheritdoc}
     */
    protected function data(ServerRequestInterface $request, Document $document)
    {

        $actor = $request->getAttribute('actor');
        $data = Arr::get($request->getParsedBody(), 'data', []);

        $validator = app('validator')->make($data, [
            'point_reason' => 'required',
            'points' => 'required|integer',
            'post_id'
        ]);

        if ($validator->fails()) {
            throw new \Illuminate\Validation\ValidationException($validator);
        }

        // Create a new point record
        $point = new Points();
        $point->point_reason = $data['point_reason'];
        $point->points = $data['points'];
        $point->post_id = $data['podt_id'];

        // $point->point_reason = 'for testing';
        // $point->points = 20;
        // $point->post_id = 1;
        // Save the point record
        $point->save();

        return $point;
    }
}
