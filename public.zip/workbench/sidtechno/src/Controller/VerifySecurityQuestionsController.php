<?php
namespace Sidtechno\Customlogin\Controller;


use Flarum\Api\Controller\AbstractCreateController;
use Illuminate\Support\Arr;
use Psr\Http\Message\ServerRequestInterface;
use Tobscure\JsonApi\Document;

class VerifySecurityQuestionsController extends AbstractCreateController
{
    // Define which serializer will be used for the response
    public $serializer = YourSerializer::class;

    public function data(ServerRequestInterface $request, Document $document)
    {
        $actor = $request->getAttribute('actor');
        $data = $request->getParsedBody();

        // Retrieve submitted answers
        $answer1 = Arr::get($data, 'answer1');

        // Retrieve stored answers from the database and compare
        // ...

        // Return a response
        // ...
    }
}
