<?php

/*
 * This file is part of sidtechno/customlogin.
 *
 * Copyright (c) 2023 Sidtechno.
 *
 * For the full copyright and license information, please view the LICENSE.md
 * file that was distributed with this source code.
 */

namespace Sidtechno\Customlogin;

use Flarum\Extend;
use Sidtechno\Customlogin\Controller\CustomLoginController;
use Sidtechno\Customlogin\Controller\PointsController;
use Sidtechno\Customlogin\Controller\PointStoreController;
use Sidtechno\Customlogin\Controller\PointController;
use Sidtechno\Customlogin\Controller\UserController;
use Sidtechno\Customlogin\Controller\CustomSignupController;
use Sidtechno\Customlogin\Controller\UserfindController;


return [
    (new Extend\Frontend('forum'))
        ->js(__DIR__.'/js/dist/forum.js')
        ->css(__DIR__.'/less/forum.less'),
    (new Extend\Frontend('admin'))
        ->js(__DIR__.'/js/dist/admin.js')
        ->css(__DIR__.'/less/admin.less'),
    new Extend\Locales(__DIR__.'/locale'),

    (new Extend\Routes('api'))
    ->get('/point/show/{id}', 'point.show', PointsController::class)
    ->get('/user/show/{id}', 'user.show', UserController::class)
    ->post('/point/store', 'point.store', PointStoreController::class)
    ->get('/point/all', 'point.all', PointController::class)
    ->get('/user/find','user.find',UserfindController::class)
    ->post('/custom-signup', 'custom-signup',CustomSignupController::class),
];
