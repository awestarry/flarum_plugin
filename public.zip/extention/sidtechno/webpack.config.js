const path = require('path');

module.exports = [
    {
        entry: {
            admin: './js/src/admin/index.js',
            forum: './js/src/forum/index.js'  // Include this if you also have frontend scripts.
        },
        output: {
            path: path.resolve(__dirname, 'js/dist'),
            filename: '[name].js'
        },
        module: {
            rules: [
                {
                    test: /\.js$/,
                    exclude: /node_modules/,
                    use: {
                        loader: 'babel-loader',
                        options: {
                            presets: ['@babel/preset-env']
                        }
                    }
                }
            ]
        },
        resolve: {
            alias: {
                'flarum': path.resolve(__dirname, 'vendor/flarum/core/js'),
            }
        },
    }
];
