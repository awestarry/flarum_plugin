// /js/src/admin/MyExtensionAdminPage.js
import app from 'flarum/admin/app';
import ExtensionPage from 'flarum/admin/components/ExtensionPage';

export default class MyExtensionAdminPage extends ExtensionPage {
    content() {
        return [
            m('.ExtensionPage-body', [
                m('.container', "Your admin content goes here.")
            ])
        ];
    }
}
