// /js/src/admin/index.js
import app from 'flarum/admin/app';
import MyExtensionAdminPage from './MyExtensionAdminPage';

app.initializers.add('sidtechno-customlogin', () => {
    app.extensionData
        .for('sidtechno-customlogin')
        .registerPage(MyExtensionAdminPage);
});
