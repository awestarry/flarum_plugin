console.log("My JS file is loaded!");

import { extend } from 'flarum/extend';
import IndexPage from 'flarum/components/IndexPage';
import ButtonComponent from './components/ButtonComponent';

export default function() {
    extend(IndexPage.prototype, 'viewItems', function(items) {
        items.add('my-custom-button', ButtonComponent);
    });
}