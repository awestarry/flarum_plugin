// js/src/forum/components/ButtonComponent.js

import Component from 'flarum/Component';

export default class ButtonComponent extends Component {
    view() {
        return m('button', {
            className: 'Button',
            onclick: this.handleClick.bind(this)
        }, 'Click Me!');
    }

    handleClick() {
        // Handle button click action here
        console.log('Button was clicked');
    }
}
