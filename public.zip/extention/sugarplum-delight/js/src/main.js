// extensions/acme/sugarplum-delight/js/src/main.js

import { extend } from 'flarum/extend';
import app from 'flarum/app';

app.initializers.add('acme-sugarplum-delight', () => {
    // Your JavaScript code here

    extend(app, 'components/homepage', function (component) {
        // Create a button to fetch questions
        component.content.add('fetch-questions', m('button', {
            onclick: () => {
                m.request({
                    method: 'GET',
                    url: app.forum.attribute('apiUrl') + '/sugarplum-delight/questions',
                }).then(response => {
                    // Handle the response from the server (e.g., update UI)
                    console.log(response);
                });
            },
        }, 'Fetch Questions'));
    });
});
