const path = require('path');

module.exports = {
  entry: {
    forum: './js/src/forum.js',    // This assumes you have a forum.js as your forum entry point
    // admin: './js/src/admin.js' // Uncomment this if you also have an admin entry point
  },
  output: {
    path: path.resolve(__dirname, 'js/dist'), // This outputs the bundled file to /js/dist directory
    // filename: '[name].js',                    // [name] will be replaced by the entry point name (forum, admin, etc.)
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env']
          }
        }
      },
    ],
  },
};
