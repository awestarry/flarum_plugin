@extends('flarum::admin.layout')

@section('content')
    <div class="container">
        <h2>Your Extension Admin Page</h2>
        <div>
            @if ($data)
                <ul>
                    @foreach ($data as $item)
                        <li>{{ $item['name'] }}</li>
                    @endforeach
                </ul>
            @else
                <p>No data available.</p>
            @endif
        </div>
    </div>
@endsection
