<?php 

namespace Acme\SugarplumDelight\Api\Serializers;

use Flarum\Api\Serializer\AbstractSerializer;

class QuestionSerializer extends AbstractSerializer
{
    protected $type = 'questions';

    protected function getDefaultAttributes($model)
    {
        return [
            'question' => $model->question, 
        ];
    }
}
