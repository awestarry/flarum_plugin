<?php


namespace Acme\SugarplumDelight\Api\Controllers;

use Flarum\Api\Controller\AbstractListController;
use Psr\Http\Message\ServerRequestInterface;
use Tobscure\JsonApi\Document;
use Acum\SugarplumDelight\Serializers\QuestionSerializer;
use Acme\SugarplumDelight\Models\Question;
class QuestionController extends AbstractListController
{
    // Define the serializer (you might need to create this separately)
    // public $serializer = QuestionSerializer::class;
    public  function data(ServerRequestInterface $request, Document $document)
{
    $questions = Question::all();
    $response = [];
    foreach ($questions as $question) {
        $response[] = [
            'type' => 'questions',
            'id'   => $question->id,
            'attributes' => [
                'content' => $question->answers,
            ],
        ];
    }

    return $response;
}
    public function testing(ServerRequestInterface $request){
        return ['message' => 'Hello from your extension API!'];
    }

    public function handle(Request $request): Response
    {
        // Fetch data from your API or other source
        $data = YourApiClient::getData(); // Example function to fetch data

        // Render the admin view with the data
        return $this->view('acme-sugarplum.admin', ['data' => $data]);
    }

}
