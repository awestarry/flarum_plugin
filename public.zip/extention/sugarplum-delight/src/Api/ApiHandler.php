<?php
namespace Acme\SugarplumDelight\Api;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface;

class ApiHandler implements RequestHandlerInterface
{
    public function handle(Request $request): Response
    {
        // Process the API request and prepare the data
        $data = [
            'message' => 'This is a sample API response.',
            'timestamp' => time(),
        ];

        // Create a JSON response
        $response = new \Laminas\Diactoros\Response\JsonResponse($data);

        return $response;
    }
}
