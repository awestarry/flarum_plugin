<?php

namespace Acme\SugarplumDelight;

use Acme\SugarplumDelight\Api\Controllers\QuestionController;
use Flarum\Extend;
use Flarum\Extend\Routes;
use Illuminate\Contracts\Events\Dispatcher;

return [
    (new Extend\Frontend('forum'))
        ->js(__DIR__.'/js/dist/forum.js')
        ->css(__DIR__.'/js/resources/less/forum.less'),

        (new Routes('api'))
         ->get('/question/records', 'sugarplum.index', QuestionController::class),
        // ->get('/api/questions', 'acme.sugarplum.questions.index', QuestionController::class),
        // ->get('/sugarplum-delight/questions', 'sugarplum-delight.questions.index', 'Acme\SugarplumDelight\Api\Controllers\QuestionController@index'),
        (new Extend\Routes('admin'))
        ->get('/testing', 'acme.sugarplum.admin', QuestionController::class),
];
