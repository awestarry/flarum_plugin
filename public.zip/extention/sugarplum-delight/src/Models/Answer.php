<?php 

namespace Acme\SugarplumDelight\Models;

use Flarum\Database\AbstractModel;

class Question extends AbstractModel
{
    protected $table = 'questions_table';
    protected $fillable = ['qs_id','answers','user_id'];
    
}
