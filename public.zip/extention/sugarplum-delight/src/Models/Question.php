<?php 

namespace Acme\SugarplumDelight\Models;

use Flarum\Database\AbstractModel;

class Question extends AbstractModel
{
    protected $table = 'questions_table';

    protected $fillable = ['question'];
    
    // Define other model methods and properties as needed
}
