<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Schema\Builder;

return [
    'up' => function (Builder $schema) {
        if ($schema->hasTable('questions')) {
            return;
        }

        $schema->create('useranswers', function (Blueprint $table) {
            $table->increments('id');
            $table->string('qs_id');
            $table->string('answers');
            $table->string('user_id');
            $table->timestamps();
        });
    },

    'down' => function (Builder $schema) {
        $schema->dropIfExists('useranswers');
    },
];
