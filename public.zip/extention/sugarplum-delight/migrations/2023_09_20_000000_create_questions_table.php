<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Schema\Builder;

return [
    'up' => function (Builder $schema) {
        if ($schema->hasTable('questions_table')) {
            return;
        }

        $schema->create('questions_table', function (Blueprint $table) {
            $table->increments('id');
            $table->string('question');        
            $table->timestamps();
        });
    },

    'down' => function (Builder $schema) {
        $schema->dropIfExists('questions_table');
    },
];
